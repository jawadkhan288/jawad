let a=45
let b=44
let c=a+b 

console.log(c)
